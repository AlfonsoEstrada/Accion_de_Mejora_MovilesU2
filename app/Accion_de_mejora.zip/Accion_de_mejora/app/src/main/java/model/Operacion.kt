package model


data class Operacion(
    val valor1: Double = 0.0,
    val valor2: Double = 0.0,
    val valor3: Double = 0.0
)